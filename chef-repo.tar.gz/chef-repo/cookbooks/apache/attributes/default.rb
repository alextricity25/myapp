default['apache']['sites']['clowns'] = { "port" => 80 } 
default['apache']['sites']['bears'] = { "port" => 81 } 
