name "dev" 
description "For developers!"
cookbook "apache", "= 0.2.0" 
